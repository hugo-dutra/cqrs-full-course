package br.com.beautique.api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BeautiqueApplicationTests {

	@Test
	void contextLoads() {
	}

}
