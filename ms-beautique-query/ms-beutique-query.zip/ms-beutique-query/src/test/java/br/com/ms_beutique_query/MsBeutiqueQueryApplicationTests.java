package br.com.ms_beutique_query;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsBeutiqueQueryApplicationTests {

	@Test
	void contextLoads() {
	}

}
