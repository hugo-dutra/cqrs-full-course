package br.com.ms_beutique_query;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MsBeutiqueQueryApplication {

	public static void main(String[] args) {
		SpringApplication.run(MsBeutiqueQueryApplication.class, args);
	}

}
